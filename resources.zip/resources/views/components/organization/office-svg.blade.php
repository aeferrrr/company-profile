<svg id="org-svg" viewBox="0 0 1200 420" width="100%" preserveAspectRatio="xMidYMid meet"
    xmlns="http://www.w3.org/2000/svg">

    <!-- CSS is handled externally or via global theme variables as provided in your snippet -->

    <!-- Garis Konektor Atas (Dari President Director ke Departemen Level 1) -->
    <g class="connector-group">
        <line x1="600" y1="90" x2="600" y2="130" class="chart-line" />
        <line x1="200" y1="130" x2="1000" y2="130" class="chart-line" />

        <line x1="200" y1="130" x2="200" y2="160" class="chart-line" />
        <line x1="400" y1="130" x2="400" y2="160" class="chart-line" />
        <line x1="600" y1="130" x2="600" y2="160" class="chart-line" />
        <line x1="800" y1="130" x2="800" y2="160" class="chart-line" />
        <line x1="1000" y1="130" x2="1000" y2="160" class="chart-line" />
    </g>

    <!-- Garis Konektor Bawah (Menuju Warehouse & Workshop) -->
    <g class="connector-group">
        <line x1="200" y1="220" x2="200" y2="280" class="chart-line" /> <!-- Dari Finance -->
        <line x1="400" y1="220" x2="400" y2="280" class="chart-line" /> <!-- Dari General Affairs -->
        <line x1="600" y1="220" x2="600" y2="280" class="chart-line" /> <!-- Dari Legal -->
        <line x1="800" y1="220" x2="800" y2="280" class="chart-line" /> <!-- Dari Engineering -->
        <line x1="1000" y1="220" x2="1000" y2="280" class="chart-line" /> <!-- Dari Marketing -->
        
        <!-- Garis horizontal bawah -->
        <line x1="200" y1="280" x2="1000" y2="280" class="chart-line" />
        
        <!-- Garis drop down ke kotak Warehouse -->
        <line x1="600" y1="280" x2="600" y2="310" class="chart-line" />
    </g>

    <!-- NODE GROUPS -->

    <!-- President Director -->
    <g class="node-group" transform="translate(510, 30)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="30" class="chart-text">President Director</text>
    </g>

    <!-- Finance Dept. -->
    <g class="node-group" transform="translate(110, 160)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="24" class="chart-text chart-text-multiline-1">Finance Dept.</text>
        <text x="90" y="44" class="chart-text" style="font-size: 11px; opacity: 0.7;">Accounting/Tax</text>
    </g>

    <!-- General Affairs Dept. -->
    <g class="node-group" transform="translate(310, 160)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="24" class="chart-text chart-text-multiline-1">General Affairs Dept.</text>
        <text x="90" y="44" class="chart-text" style="font-size: 11px; opacity: 0.7;">CS Department</text>
    </g>

    <!-- Legal Dept. -->
    <g class="node-group" transform="translate(510, 160)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="30" class="chart-text">Legal Dept.</text>
    </g>

    <!-- Engineering Dept. -->
    <g class="node-group" transform="translate(710, 160)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="24" class="chart-text chart-text-multiline-1">Engineering Dept.</text>
        <text x="90" y="44" class="chart-text" style="font-size: 11px; opacity: 0.7;">PQ, BQ</text>
    </g>

    <!-- Marketing Dept. -->
    <g class="node-group" transform="translate(910, 160)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="30" class="chart-text">Marketing Dept.</text>
    </g>

    <!-- Warehouse & Workshop -->
    <g class="node-group" transform="translate(510, 310)">
        <rect width="180" height="60" class="chart-rect" />
        <text x="90" y="30" class="chart-text">Warehouse &amp; Workshop</text>
    </g>

</svg>